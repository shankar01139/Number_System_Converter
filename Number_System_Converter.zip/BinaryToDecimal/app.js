function getResult() {
    const decimalNum = parseInt(document.getElementById("val").value);
    let convertedNum = undefined;
    let indexValue = document.getElementById('num').selectedIndex;
    let options = document.getElementById('num').options;
    let selectedConversionSystem = options[indexValue].text;
    if (selectedConversionSystem === 'Binary')
        convertedNum = decimalNum.toString(2);
    else if (selectedConversionSystem === 'Octa-Decimal')
        convertedNum = decimalNum.toString(8);
    else if (selectedConversionSystem === 'Hexa-Decimal')
    {
        convertedNum = decimalNum.toString(16);
        convertedNum=convertedNum.toUpperCase();
    }
    if (document.getElementById('output')) {
        let element = document.getElementById('output');
        element.parentNode.removeChild(element);
    }
    addElement('container', 'h1', 'output', decimalNum,
        convertedNum, selectedConversionSystem);
}

function addElement(parentId, elementTag, elementId,
    decimalNum, number, selectedConversionSystem) {
    let html = `Decimal number ${decimalNum} to 
    ${selectedConversionSystem} is ${number}`;
    let p = document.getElementById(parentId);
    let newElement = document.createElement(elementTag);
    newElement.setAttribute('id', elementId);
    newElement.style.color = 'red';
    newElement.style.marginTop = '100px';
    newElement.style.textAlign = 'center';
    newElement.style.display = 'flex';
    newElement.style.whiteSpace = 'nowrap';
    newElement.style.overFlow = 'hidden';
    newElement.style.fontSize = '1rem';
    newElement.innerHTML = html;
    p.appendChild(newElement);
}